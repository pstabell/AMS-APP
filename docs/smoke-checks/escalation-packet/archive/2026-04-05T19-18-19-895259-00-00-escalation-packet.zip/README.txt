AMS-APP Render Escalation Packet
Generated at: 2026-04-05T19:18:19.895259+00:00
Severity: critical
Owner: Traction
Destination: Render support

What this packet is:
A send-ready evidence bundle for the current Render webhook routing outage blocking live Stripe trial signup validation.

Primary requested action:
Confirm the webhook hostname is attached to commission-tracker-webhook, redeploy the service, and recheck /health until x-render-routing=no-server disappears.

Recommended packet files:
- docs/smoke-checks/latest-trial-signup-smoke-check.json
- docs/smoke-checks/latest-trial-signup-smoke-check.md
- render.yaml
- docs/smoke-checks/owner-ready/render_support.txt
- docs/smoke-checks/escalation-packet/render-support-message.txt
- docs/smoke-checks/escalation-packet/render-support-payload.json
- docs/smoke-checks/escalation-packet/evidence-manifest.json
- docs/smoke-checks/escalation-packet/README.txt
- docs/smoke-checks/escalation-packet/escalation-packet.zip
- docs/smoke-checks/escalation-packet/escalation-packet.zip.sha256

Broader recommended attachments:
- docs/smoke-checks/latest-trial-signup-smoke-check.json
- docs/smoke-checks/latest-trial-signup-smoke-check.md
- docs/TRIAL_SIGNUP_E2E_REPORT_2026-04-01.md
- render.yaml
- docs/smoke-checks/owner-ready/traction.txt
- docs/smoke-checks/owner-ready/render_support.txt
- docs/smoke-checks/escalation-packet/render-support-message.txt
- docs/smoke-checks/escalation-packet/render-support-payload.json
- docs/smoke-checks/escalation-packet/evidence-manifest.json
- docs/smoke-checks/escalation-packet/README.txt
- docs/smoke-checks/escalation-packet/escalation-packet.zip
- docs/smoke-checks/escalation-packet/escalation-packet.zip.sha256

Live verification shell still needs these secrets before the final Stripe test:
- STRIPE_SECRET_KEY
- STRIPE_WEBHOOK_SECRET
- STRIPE_PRICE_ID
- RESEND_API_KEY
- SUPABASE_SERVICE_KEY

Integrity hashes:
- README.txt: sha256=17a81bb19c439aca1bea9c321da1ef78f0be2b942212d33db247a50bb02fcb94 size_bytes=3139
- evidence-manifest.json: sha256=4712eee2ce2f8882abaf47f866cc8090d26211e16683944b92f4a03bf72e17f2 size_bytes=9955
- latest-trial-signup-smoke-check.json: path=docs/smoke-checks/latest-trial-signup-smoke-check.json sha256=1c23c43d8beeb71512a8285cc54b164beb08f96f38d4537f62c1208ce31608d7 size_bytes=46039
- latest-trial-signup-smoke-check.md: path=docs/smoke-checks/latest-trial-signup-smoke-check.md sha256=5a1ae33f1e0455cfb65e2291ed1dec7216aec401fe87e785af24fc4048b41390 size_bytes=30434
- render-support-message.txt: sha256=0a9d18b0a5405426ac6cdce21d2067346466e45751ccee6237bdb0f4081f5184 size_bytes=2406
- render-support-payload.json: sha256=28a2846be676d3f71f79aad65d8706d0ed3ce0618de83de7f8e2ba951c767c0c size_bytes=1392

If forwarding to Render support:
1. Use escalation-packet.zip if the support channel accepts a single attachment, or send the individual files below.
2. Send render-support-message.txt as the support message body.
3. Attach render-support-payload.json and evidence-manifest.json.
4. Include the latest smoke-check JSON/Markdown artifacts and render.yaml from the packet file list above.
5. If packet integrity is questioned later, compare the attached files against the sha256 hashes listed above.
