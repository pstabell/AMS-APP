AMS-APP Render Escalation Packet
Generated at: 2026-04-06T03:17:57.614812+00:00
Severity: critical
Owner: Traction
Destination: Render support

What this packet is:
A send-ready evidence bundle for the current Render webhook routing outage blocking live Stripe trial signup validation.

Primary requested action:
Confirm the webhook hostname is attached to commission-tracker-webhook, redeploy the service, and recheck /health until x-render-routing=no-server disappears.

Recommended packet files:
- docs/smoke-checks/latest-trial-signup-smoke-check.json
- docs/smoke-checks/latest-trial-signup-smoke-check.md
- render.yaml
- docs/smoke-checks/owner-ready/render_support.txt
- docs/smoke-checks/escalation-packet/render-support-message.txt
- docs/smoke-checks/escalation-packet/render-support-payload.json
- docs/smoke-checks/escalation-packet/evidence-manifest.json
- docs/smoke-checks/escalation-packet/README.txt
- docs/smoke-checks/escalation-packet/escalation-packet.zip
- docs/smoke-checks/escalation-packet/escalation-packet.zip.sha256

Broader recommended attachments:
- docs/smoke-checks/latest-trial-signup-smoke-check.json
- docs/smoke-checks/latest-trial-signup-smoke-check.md
- docs/TRIAL_SIGNUP_E2E_REPORT_2026-04-01.md
- render.yaml
- docs/smoke-checks/owner-ready/traction.txt
- docs/smoke-checks/owner-ready/render_support.txt
- docs/smoke-checks/escalation-packet/render-support-message.txt
- docs/smoke-checks/escalation-packet/render-support-payload.json
- docs/smoke-checks/escalation-packet/evidence-manifest.json
- docs/smoke-checks/escalation-packet/README.txt
- docs/smoke-checks/escalation-packet/escalation-packet.zip
- docs/smoke-checks/escalation-packet/escalation-packet.zip.sha256

Live verification shell still needs these secrets before the final Stripe test:
- STRIPE_SECRET_KEY
- STRIPE_WEBHOOK_SECRET
- STRIPE_PRICE_ID
- RESEND_API_KEY
- SUPABASE_SERVICE_KEY

Integrity hashes:
- README.txt: sha256=47937ef39643d908074744547d324e939f5ecebe31069d40c8650d2c1d789111 size_bytes=3140
- evidence-manifest.json: sha256=69d4d919d60c4ead7eb08c57d583f21f04d347e27c16e25ceb711c41079632b5 size_bytes=10069
- latest-trial-signup-smoke-check.json: path=docs/smoke-checks/latest-trial-signup-smoke-check.json sha256=96ad5b6ee5e2abaf6f9b077b95d942456084cc43396ed10eb2d4b7f295f44811 size_bytes=53058
- latest-trial-signup-smoke-check.md: path=docs/smoke-checks/latest-trial-signup-smoke-check.md sha256=2711b509baf4ff72832b660ef8657335578bbe2c1c6ade632307880e872825d0 size_bytes=33669
- render-support-message.txt: sha256=aa26580d48670616a453e25a982957abe1b87a492b33acb22bd5521c9ef33888 size_bytes=2406
- render-support-payload.json: sha256=e4adbef1313bde4b55733b841f5f7b9c373971c03b262621e17186872ad5ebb3 size_bytes=1392

If forwarding to Render support:
1. Use escalation-packet.zip if the support channel accepts a single attachment, or send the individual files below.
2. Send render-support-message.txt as the support message body.
3. Attach render-support-payload.json and evidence-manifest.json.
4. Include the latest smoke-check JSON/Markdown artifacts and render.yaml from the packet file list above.
5. If packet integrity is questioned later, compare the attached files against the sha256 hashes listed above.
