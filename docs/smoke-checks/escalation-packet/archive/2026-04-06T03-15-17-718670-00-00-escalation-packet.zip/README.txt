AMS-APP Render Escalation Packet
Generated at: 2026-04-06T03:15:17.718670+00:00
Severity: critical
Owner: Traction
Destination: Render support

What this packet is:
A send-ready evidence bundle for the current Render webhook routing outage blocking live Stripe trial signup validation.

Primary requested action:
Confirm the webhook hostname is attached to commission-tracker-webhook, redeploy the service, and recheck /health until x-render-routing=no-server disappears.

Recommended packet files:
- docs/smoke-checks/latest-trial-signup-smoke-check.json
- docs/smoke-checks/latest-trial-signup-smoke-check.md
- render.yaml
- docs/smoke-checks/owner-ready/render_support.txt
- docs/smoke-checks/escalation-packet/render-support-message.txt
- docs/smoke-checks/escalation-packet/render-support-payload.json
- docs/smoke-checks/escalation-packet/evidence-manifest.json
- docs/smoke-checks/escalation-packet/README.txt
- docs/smoke-checks/escalation-packet/escalation-packet.zip
- docs/smoke-checks/escalation-packet/escalation-packet.zip.sha256

Broader recommended attachments:
- docs/smoke-checks/latest-trial-signup-smoke-check.json
- docs/smoke-checks/latest-trial-signup-smoke-check.md
- docs/TRIAL_SIGNUP_E2E_REPORT_2026-04-01.md
- render.yaml
- docs/smoke-checks/owner-ready/traction.txt
- docs/smoke-checks/owner-ready/render_support.txt
- docs/smoke-checks/escalation-packet/render-support-message.txt
- docs/smoke-checks/escalation-packet/render-support-payload.json
- docs/smoke-checks/escalation-packet/evidence-manifest.json
- docs/smoke-checks/escalation-packet/README.txt
- docs/smoke-checks/escalation-packet/escalation-packet.zip
- docs/smoke-checks/escalation-packet/escalation-packet.zip.sha256

Live verification shell still needs these secrets before the final Stripe test:
- STRIPE_SECRET_KEY
- STRIPE_WEBHOOK_SECRET
- STRIPE_PRICE_ID
- RESEND_API_KEY
- SUPABASE_SERVICE_KEY

Integrity hashes:
- README.txt: sha256=f0345c86bb8ca1a772dec8e567bc756b6003c86fb8855c221010e36883551c02 size_bytes=3140
- evidence-manifest.json: sha256=f9f404f4f7434b3475caa907f07a9e27c667cc9208a9348a3410d8c7839eede1 size_bytes=10069
- latest-trial-signup-smoke-check.json: path=docs/smoke-checks/latest-trial-signup-smoke-check.json sha256=9b8fe3842084702e1ec056ae63f9645fe57cb9b32b119a696c38ddfdb81bedce size_bytes=50899
- latest-trial-signup-smoke-check.md: path=docs/smoke-checks/latest-trial-signup-smoke-check.md sha256=3d7f4cd61e600aa4aae911799bb9d5fc1358cd7902d53f46b69411dfcaa9dc29 size_bytes=32689
- render-support-message.txt: sha256=26cd3561bd0297f1f8675a75316e712ddf152d0fca7a7743cd779b688ac33b9b size_bytes=2406
- render-support-payload.json: sha256=10208c32ddade411acfcc28c98277f0781ba778a02c803e51f708db59fb237c7 size_bytes=1392

If forwarding to Render support:
1. Use escalation-packet.zip if the support channel accepts a single attachment, or send the individual files below.
2. Send render-support-message.txt as the support message body.
3. Attach render-support-payload.json and evidence-manifest.json.
4. Include the latest smoke-check JSON/Markdown artifacts and render.yaml from the packet file list above.
5. If packet integrity is questioned later, compare the attached files against the sha256 hashes listed above.
